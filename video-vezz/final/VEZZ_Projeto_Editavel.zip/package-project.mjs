// Portable ZIP builder (deflate + CRC32). No system archiver or extra package.
import {readFile,writeFile,readdir,stat} from 'node:fs/promises';
import {deflateRawSync} from 'node:zlib';
import path from 'node:path';
import {spawn} from 'node:child_process';
const files=[];
async function walk(folder){for(const e of await readdir(folder,{withFileTypes:true})){const name=folder+'/'+e.name;if(e.isDirectory())await walk(name);else files.push(name);}}
for(const d of ['src','capture','audio','docs','public'])await walk(d);
files.push('package.json','package-lock.json','README.md','render.mjs','verify.mjs','package-project.mjs','raw/capture-manifest.json','final/quality-report.json');
const table=Array.from({length:256},(_,i)=>{let c=i;for(let j=0;j<8;j++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
function crc32(b){let crc=0xffffffff;for(const x of b)crc=table[(crc^x)&255]^(crc>>>8);return (crc^0xffffffff)>>>0;}
const locals=[],central=[];let offset=0;
for(const filename of files){
  const raw=await readFile(filename),compressed=deflateRawSync(raw,{level:6}),name=Buffer.from(filename.replaceAll('\\','/'));const crc=crc32(raw);
  const modified=new Date((await stat(filename)).mtime),year=Math.max(1980,modified.getFullYear());
  const date=((year-1980)<<9)|((modified.getMonth()+1)<<5)|modified.getDate();const time=(modified.getHours()<<11)|(modified.getMinutes()<<5)|Math.floor(modified.getSeconds()/2);
  const h=Buffer.alloc(30);h.writeUInt32LE(0x04034b50,0);h.writeUInt16LE(20,4);h.writeUInt16LE(0x800,6);h.writeUInt16LE(8,8);h.writeUInt16LE(time,10);h.writeUInt16LE(date,12);h.writeUInt32LE(crc,14);h.writeUInt32LE(compressed.length,18);h.writeUInt32LE(raw.length,22);h.writeUInt16LE(name.length,26);
  locals.push(h,name,compressed);
  const c=Buffer.alloc(46);c.writeUInt32LE(0x02014b50,0);c.writeUInt16LE(20,4);c.writeUInt16LE(20,6);c.writeUInt16LE(0x800,8);c.writeUInt16LE(8,10);c.writeUInt16LE(time,12);c.writeUInt16LE(date,14);c.writeUInt32LE(crc,16);c.writeUInt32LE(compressed.length,20);c.writeUInt32LE(raw.length,24);c.writeUInt16LE(name.length,28);c.writeUInt32LE(offset,42);central.push(c,name);
  offset+=h.length+name.length+compressed.length;
}
const directory=Buffer.concat(central);const end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(files.length,8);end.writeUInt16LE(files.length,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);
const zip=Buffer.concat([...locals,directory,end]);await writeFile('final/VEZZ_Projeto_Editavel.zip',zip);
await new Promise((resolve,reject)=>{
  const p=spawn('python',['-c','import zipfile; z=zipfile.ZipFile("final/VEZZ_Projeto_Editavel.zip"); bad=z.testzip(); assert bad is None, bad; print("ZIP CRC and decompression verified:", len(z.infolist()), "files")'],{windowsHide:true,stdio:'inherit'});
  p.on('error',reject);p.on('exit',code=>code===0?resolve():reject(Error('ZIP validation failed: '+code)));
});
await writeFile('final/project-files.json',JSON.stringify({archive:'VEZZ_Projeto_Editavel.zip',bytes:zip.length,crcAndDecompressionVerified:true,files},null,2));
console.log('EDITABLE PROJECT',files.length+' files',Math.round(zip.length/1048576)+' MiB');
